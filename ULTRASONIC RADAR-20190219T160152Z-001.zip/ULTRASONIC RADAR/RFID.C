//ULTRASONIC RADAR WITH OBJECT MOVEMENT USING TWO ULTRASONICS AND MOTOR  
#include <LPC214X.H> /* LPC214x definitions */
#include "lcd1.h"
#include "delay.h"
void Display(void);
void mfor(void);
void mrev(void);
void DtoH1(void);
void DtoH(void);
unsigned char ones,tens,hundreds,thousands;
unsigned int temp;
#define trig 1<<23
#define	echo (0x00400000&IOPIN1)
#define trig1 1<<25
#define	echo1 (0x01000000&IOPIN1)
#define mot0 1<<2
#define mot1 1<<3
void Display(void);
unsigned int x,y,v1,v2=0;
int main (void) 
{ 

	VPBDIV = 0x02; 
  IO0DIR|=(mot0);
	IO0DIR|=(mot1);
	IOCLR0=mot0;
	IOCLR0=mot1;
	
	
	IO1DIR|=(trig);
	IO1DIR|=(trig1);
	IO1DIR&=~(echo);
	IO1DIR&=~(echo1);
	
	Lcd_Init();						// Initialize LCD
  delay_sec(10);
  Lcd_Cmd(0x01);						// clear display
	Lcd_String("ULTRASONIC ",0X80);
	Lcd_String("***RADAR***",0XC0);
 	delay_sec(100);//1 sec
	Lcd_Cmd(0x01);
  Lcd_String("D:   Cm D2:   Cm",0X80);
  Lcd_String("Vel:       ",0XC0);
	delay_sec(100);	  //1 sec
	while(1)
	{	
	x=0;	
	IO1SET=trig;
  delay_us(1000);//10 microseconds delay
  IO1CLR=trig;	
	while(!echo);	
	while(echo)
	x++;
  v1=x;	
	x/=58;//convertion into Cm
	Lcd_Cmd(0x82);	
	DtoH();
	Display();


  y=0;	
	IO1SET=trig1;
  delay_us(1000);//10 microseconds delay
  IO1CLR=trig1;
	while(!echo1);	
	while(echo1)	
	y++;
	v2=y;
  y/=58;//convertion into Cm	
//so multiplied with 10	
  Lcd_Cmd(0x8B);
	DtoH1();
	Display();
	if((x+5)<y)
	mfor();	
	else if((y+5)<x)
	mrev();	
	else
	{
IOCLR0=mot0;
IOCLR0=mot1;
delay_sec(10);		
}}





}
void DtoH()
{	  
		temp = x;
		ones = temp % 10;
		temp = temp / 10;
		tens = temp % 10;
		temp = temp / 10;
		hundreds = temp % 10;	
}
void DtoH1()
{	  
		temp = y;
		ones = temp % 10;
		temp = temp / 10;
		tens = temp % 10;
		temp = temp / 10;
		hundreds = temp % 10;	
}
void Display()
{
	  ones |= 0x30;
		tens |= 0x30;
		hundreds |= 0x30;//ascii conversion 1=0x31
		Lcd_Data(hundreds);
		Lcd_Data(tens);
		Lcd_Data(ones);
}
void mfor()
{
IO0SET=mot0;
IO0CLR=mot1;
delay_sec(15);
v1/=15;
Lcd_Cmd(0xC5);
DtoH();	
Display();
IO0CLR=mot0;
IO0CLR=mot1;
delay_sec(15);
}
void mrev()
{
IO0SET=mot1;
IO0CLR=mot0;
delay_sec(15);
v2/=15;
Lcd_Cmd(0xC5);
DtoH1();
Display();
IO0CLR=mot0;
IO0CLR=mot1;
delay_sec(15);
}




