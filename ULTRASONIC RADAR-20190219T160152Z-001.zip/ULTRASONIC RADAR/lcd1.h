

/**********LCD Pin Configuration**********/
#define RS 0x10000
//#define RW 0x40000
#define EN 0x20000
//These all are connected on Port-1 of Controller, so make sure before using IOSET and IOCLR Functions
/*****************************************/

/***********FUNCTION PROTOTYPE***********/
void Delay(unsigned int msec);
void Write_Cmd(unsigned int value);
void Write_Data(unsigned int value);
void Lcd_Init(void);                        //Initialize Lcd Module
void Lcd_Data(unsigned int value);
void Lcd_Cmd(unsigned int value);
void Lcd_String(unsigned char*,unsigned char);
/****************************************/



/***********FUNCTION DEFINITION************/

void Delay(unsigned int msec)
{
	unsigned int i,j;
  for(i=0;i<msec;i++)
	for(j=0;j<2275;j++);
	}

void Lcd_Init(void)
{    
    IO1DIR |= 0x003F0000;
    Delay(20);
    Write_Cmd(0x30<<14);
    Delay(10);
    Write_Cmd(0x20<<14);
    //These are the Commands for LCD Initialization in 4-Bit Mode
	  Lcd_Cmd(0x28);
    Lcd_Cmd(0x01);
    Lcd_Cmd(0x06);
    Lcd_Cmd(0x0C);
	  Delay(10);
}

void Write_Cmd(unsigned int value)
{
    //First of all Clear the LCD Data Pins
    IO1CLR |= 0x003C0000;
    //To Write RW = 0
//    IO0CLR |= RW;
    //Write to Command Register RS = 0
    IO1CLR |= RS;
    //Write to Pins
    IO1SET |= 0x003C0000 & value;
    IO1SET |= EN;
    Delay(5);
    IO1CLR |= EN;
}

void Write_Data(unsigned int value)
{
     //First of all Clear the LCD Data Pins
    IO1CLR |= 0x003C0000;
    //To Write RW = 0
    //IO0CLR |= RW;
    //Write to Data Register RS = 1
    IO1SET |= RS;
    //Write to Pins
    IO1SET |= 0x003C0000 & value;
    IO1SET |= EN;
    Delay(5);
    IO1CLR |= EN;
}
void Lcd_Cmd(unsigned int value)
{
    Write_Cmd(value<<14);
    Write_Cmd(value<<18);
	  Delay(5);
}
void Lcd_Data(unsigned int value)
{
    Write_Data(value<<14);
    Write_Data(value<<18);
	  Delay(5);
}
void Lcd_String(unsigned char *y,unsigned char k)
{
    Lcd_Cmd(k);
    Delay(5);
    while(*y !='\0')
    {
        Lcd_Data(*y);
        y++;
			  Delay(5); 
    }
}
/*******************************************/
